import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist

import numpy as np
import math
import random
import time

from my_robot.td3_agent import TD3Agent


class DRLEnv(Node):
    def __init__(self):
        super().__init__('drl_env')

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.scan_callback, 10)
        self.odom_sub = self.create_subscription(
            Odometry, '/odom', self.odom_callback, 10)

        self.ranges = None
        self.robot_x = 0.0
        self.robot_y = 0.0
        self.robot_yaw = 0.0

        # Goal
        self.goal_x = 2.0
        self.goal_y = 0.0

        self.num_sectors = 24
        self.prev_distance = None

    # ========================
    # CALLBACKS
    # ========================
    def scan_callback(self, msg):
        self.ranges = np.array(msg.ranges)
        self.ranges[np.isinf(self.ranges)] = msg.range_max

    def odom_callback(self, msg):
        self.robot_x = msg.pose.pose.position.x
        self.robot_y = msg.pose.pose.position.y

        q = msg.pose.pose.orientation
        siny = 2 * (q.w * q.z + q.x * q.y)
        cosy = 1 - 2 * (q.y * q.y + q.z * q.z)
        self.robot_yaw = math.atan2(siny, cosy)

    # ========================
    # STATE
    # ========================
    def get_state(self):
        if self.ranges is None:
            return None

        sector_size = len(self.ranges) // self.num_sectors
        state = []

        for i in range(self.num_sectors):
            sector = self.ranges[i*sector_size:(i+1)*sector_size]
            state.append(np.min(sector) / 3.5)

        dx = self.goal_x - self.robot_x
        dy = self.goal_y - self.robot_y

        distance = math.sqrt(dx**2 + dy**2)

        angle = math.atan2(dy, dx) - self.robot_yaw
        angle = math.atan2(math.sin(angle), math.cos(angle))

        state.append(min(distance / 10.0, 1.0))
        state.append(angle)

        return np.array(state), distance

    # ========================
    # STEP
    # ========================
    def step(self, action):
        while self.ranges is None:
            rclpy.spin_once(self)

        move = Twist()
        move.linear.x = float(action[0])
        move.angular.z = float(action[1])

        self.cmd_pub.publish(move)

        rclpy.spin_once(self)

        state, distance = self.get_state()

        reward = 0.0
        done = False

        # Progress reward
        if self.prev_distance is not None:
            reward += (self.prev_distance - distance) * 10

        self.prev_distance = distance

        # Collision
        if np.min(self.ranges) < 0.2:
            reward -= 100
            done = True
            self.get_logger().warn("💥 COLLISION!")

        # Goal reached
        if distance < 0.1:
            reward += 100
            done = True
            self.get_logger().info("🎯 GOAL REACHED!")

        reward -= 0.1  # time penalty

        if done:
            stop = Twist()
            self.cmd_pub.publish(stop)

        return state, reward, done

    # ========================
    # RESET (SIMPLE & STABLE)
    # ========================
    def reset_robot_position(self):
        self.get_logger().info("🔄 Resetting episode (no teleport)")

        stop = Twist()
        self.cmd_pub.publish(stop)

        time.sleep(1.0)

    # ========================
    # RESET FUNCTION
    # ========================
    def reset(self):
        self.prev_distance = None

        self.reset_robot_position()

        self.ranges = None
        while self.ranges is None:
            rclpy.spin_once(self)

        state, _ = self.get_state()
        return state


# ========================
# MAIN LOOP
# ========================
def main():
    rclpy.init()
    env = DRLEnv()

    agent = TD3Agent()

    while rclpy.ok():
        env.get_logger().info("🔁 NEW EPISODE")

        state = env.reset()

        for step in range(100):

            action = agent.select_action(state)

            next_state, reward, done = env.step(action)

            agent.buffer.add((state, action, reward, next_state, float(done)))

            agent.train()

            state = next_state

            env.get_logger().info(f"Reward: {reward:.2f}")

            time.sleep(0.05)

            if done:
                env.get_logger().info("🛑 EPISODE END")
                break

    rclpy.shutdown()


if __name__ == '__main__':
    main()
