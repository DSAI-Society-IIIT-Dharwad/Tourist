import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan

class LidarReader(Node):
    def __init__(self):
        super().__init__('lidar_reader')

        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )

    def scan_callback(self, msg):
        ranges = list(msg.ranges)

        # Replace inf with max range
        processed = [r if r != float('inf') else msg.range_max for r in ranges]

        # Closest obstacle
        min_dist = min(processed)

        if min_dist < 0.5:
            self.get_logger().warn(f"⚠️ Obstacle VERY CLOSE: {min_dist}")
        else:
            self.get_logger().info(f"Safe | Closest: {min_dist}")

def main():
    rclpy.init()
    node = LidarReader()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
