import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
import numpy as np
import math

class StateProcessor(Node):
    def __init__(self):
        super().__init__('state_processor')

        # Subscribers
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )

        self.odom_sub = self.create_subscription(
            Odometry,
            '/odom',
            self.odom_callback,
            10
        )

        self.num_sectors = 24

        # Robot pose
        self.robot_x = 0.0
        self.robot_y = 0.0
        self.robot_yaw = 0.0

        # 🎯 Goal position (change if needed)
        self.goal_x = 2.0
        self.goal_y = 0.0

        # For reward calculation
        self.prev_distance = None

    def odom_callback(self, msg):
        self.robot_x = msg.pose.pose.position.x
        self.robot_y = msg.pose.pose.position.y

        # Convert quaternion → yaw
        q = msg.pose.pose.orientation
        siny = 2 * (q.w * q.z + q.x * q.y)
        cosy = 1 - 2 * (q.y * q.y + q.z * q.z)
        self.robot_yaw = math.atan2(siny, cosy)

    def scan_callback(self, msg):
        ranges = np.array(msg.ranges)

        # Replace inf values
        ranges[np.isinf(ranges)] = msg.range_max

        # 🔹 Convert LiDAR → 24 sectors
        sector_size = len(ranges) // self.num_sectors
        state = []

        for i in range(self.num_sectors):
            start = i * sector_size
            end = (i + 1) * sector_size

            sector = ranges[start:end]
            min_dist = np.min(sector)

            normalized = min_dist / msg.range_max
            state.append(normalized)

        # 🔹 Goal calculations
        dx = self.goal_x - self.robot_x
        dy = self.goal_y - self.robot_y

        distance_to_goal = math.sqrt(dx**2 + dy**2)

        angle_to_goal = math.atan2(dy, dx) - self.robot_yaw
        angle_to_goal = math.atan2(math.sin(angle_to_goal), math.cos(angle_to_goal))

        # Normalize distance (0–1)
        distance_norm = min(distance_to_goal / 10.0, 1.0)

        state.append(distance_norm)
        state.append(angle_to_goal)

        state = np.array(state)

        # 🔥 REWARD FUNCTION
        reward = 0.0
        done = False

        # 1️⃣ Progress reward
        if self.prev_distance is not None:
            progress = self.prev_distance - distance_to_goal
            reward += progress * 10

        self.prev_distance = distance_to_goal

        # 2️⃣ Collision penalty
        min_lidar = np.min(ranges)

        if min_lidar < 0.2:
            reward -= 100
            done = True
            self.get_logger().warn("💥 COLLISION!")

        # 3️⃣ Goal reached
        if distance_to_goal < 0.05:
            reward += 100
            done = True
            self.get_logger().info("🎯 GOAL REACHED!")

        # 4️⃣ Time penalty
        reward -= 0.1

        # 🔹 Print everything
        self.get_logger().info(f"State: {state}")
        self.get_logger().info(f"Reward: {reward:.2f} | Done: {done}")

def main():
    rclpy.init()
    node = StateProcessor()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
