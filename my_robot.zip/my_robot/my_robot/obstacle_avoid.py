import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

class ObstacleAvoid(Node):
    def __init__(self):
        super().__init__('obstacle_avoid')

        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)

        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )

    def scan_callback(self, msg):
        ranges = list(msg.ranges)

        # Clean data
        processed = [r if r != float('inf') else msg.range_max for r in ranges]

        # 🔥 Narrow front (very important)
        front = processed[:15] + processed[-15:]

        # Slight left/right front
        front_left = processed[15:60]
        front_right = processed[-60:-15]

        min_front = min(front)
        min_left = min(front_left)
        min_right = min(front_right)

        move = Twist()

        # 🚨 VERY CLOSE → ESCAPE
        if min_front < 0.4:
            move.linear.x = 0.0

            if min_left > min_right:
                move.angular.z = 1.2
                self.get_logger().warn("ESCAPE LEFT")
            else:
                move.angular.z = -1.2
                self.get_logger().warn("ESCAPE RIGHT")

        # ⚠️ OBSTACLE AHEAD
        elif min_front < 0.8:
            move.linear.x = 0.05

            if min_left > min_right:
                move.angular.z = 0.8
                self.get_logger().warn("Avoid LEFT")
            else:
                move.angular.z = -0.8
                self.get_logger().warn("Avoid RIGHT")

        # ✅ CLEAR PATH
        else:
            move.linear.x = 0.3
            move.angular.z = 0.0
            self.get_logger().info("Forward")

        self.publisher_.publish(move)

def main():
    rclpy.init()
    node = ObstacleAvoid()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
