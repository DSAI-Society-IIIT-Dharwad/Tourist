from setuptools import find_packages, setup

package_name = 'my_robot'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='soham',
    maintainer_email='soham@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': ['my_node=my_robot.my_first_node:main','lidar_reader=my_robot.lidar_reader:main','obstacle_avoid = my_robot.obstacle_avoid:main','state_processor = my_robot.state_processor:main','drl_env = my_robot.drl_env:main','td3_agent = my_robot.td3_agent:main',],

    },
)
